package dev.trabalhopicpay.entitys.user;

// Tipos de usuários
public enum UserType {
    COMMON,
    MERCHANT
}
