package dev.trabalhopicpay.dtos.requests;

// (mock - SendNotification)
public class RequestSendNotification {

    public String email;
    public String mensagem;

}
